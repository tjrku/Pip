import unittest
import os
import tempfile
from unittest.mock import patch, Mock
from jafrdow import JafrDow
from jafrdow.exceptions import APIError, DownloadError

class TestJafrDow(unittest.TestCase):
    
    def setUp(self):
        """إعداد البيئة قبل كل اختبار"""
        self.downloader = JafrDow()
        self.test_url = "https://www.tiktok.com/@test/video/123456"
    
    def test_initialization(self):
        """اختبار تهيئة الكائن"""
        self.assertEqual(self.downloader.api_url, "https://sii3.top/api/do.php")
        self.assertEqual(self.downloader.timeout, 30)
        self.assertEqual(self.downloader.download_folder, "jafrdow_downloads")
    
    def test_validate_url_valid(self):
        """اختبار التحقق من الروابط الصالحة"""
        valid_urls = [
            "https://www.tiktok.com/@user/video/123",
            "https://youtube.com/watch?v=abc123",
            "https://www.instagram.com/p/ABC123/",
            "https://twitter.com/user/status/123456",
            "https://vm.tiktok.com/XYZ789/",
        ]
        
        for url in valid_urls:
            with self.subTest(url=url):
                self.assertTrue(self.downloader._validate_url(url))
    
    def test_validate_url_invalid(self):
        """اختبار التحقق من الروابط غير الصالحة"""
        invalid_urls = [
            "https://example.com",
            "not-a-url",
            "ftp://server.com/file",
            "",
        ]
        
        for url in invalid_urls:
            with self.subTest(url=url):
                self.assertFalse(self.downloader._validate_url(url))
    
    def test_generate_unique_filename(self):
        """اختبار إنشاء أسماء ملفات فريدة"""
        title = "Test Video #123 🎥"
        filename = self.downloader._generate_unique_filename(title)
        
        self.assertTrue(filename.endswith('.mp4'))
        self.assertNotIn('#', filename)
        self.assertNotIn('🎥', filename)
    
    @patch('jafrdow.core.requests.Session.get')
    def test_get_video_info_success(self, mock_get):
        """اختبار الحصول على معلومات الفيديو بنجاح"""
        # محاكاة رد API
        mock_response = Mock()
        mock_response.json.return_value = {
            "date": "2024-01-01",
            "title": "Test Video",
            "links": [{"url": "http://example.com/video.mp4", "type": "video", "ext": "mp4"}]
        }
        mock_response.raise_for_status.return_value = None
        mock_get.return_value = mock_response
        
        result = self.downloader.get_video_info(self.test_url)
        
        self.assertEqual(result["title"], "Test Video")
        self.assertIn("links", result)
    
    @patch('jafrdow.core.requests.Session.get')
    def test_get_video_info_failure(self, mock_get):
        """اختبار فشل الحصول على معلومات الفيديو"""
        mock_get.side_effect = Exception("API Error")
        
        with self.assertRaises(APIError):
            self.downloader.get_video_info(self.test_url)
    
    def test_format_size(self):
        """اختبار تنسيق أحجام الملفات"""
        self.assertEqual(self.downloader._format_size(500), "500.0 B")
        self.assertEqual(self.downloader._format_size(1500), "1.5 KB")
        self.assertEqual(self.downloader._format_size(1500000), "1.4 MB")
    
    def test_format_time(self):
        """اختبار تنسيق الأوقات"""
        self.assertEqual(self.downloader._format_time(45), "45 ثانية")
        self.assertEqual(self.downloader._format_time(125), "2 دقيقة 5 ثانية")
        self.assertEqual(self.downloader._format_time(3665), "1 ساعة 1 دقيقة")
    
    def test_shorten_url(self):
        """اختبار تقصير الروابط الطويلة"""
        long_url = "https://www.tiktok.com/@very_long_username/video/123456789012345"
        shortened = self.downloader._shorten_url(long_url)
        
        self.assertTrue(len(shortened) <= 50)
        self.assertIn("...", shortened)
    
    def test_download_folder_creation(self):
        """اختبار إنشاء مجلد التنزيلات"""
        self.assertTrue(os.path.exists(self.downloader.download_folder))
    
    def test_sort_links_by_quality(self):
        """اختبار فرز الروابط حسب الجودة"""
        links = [
            {"quality": "mp4 (360p)", "url": "url1"},
            {"quality": "mp4 (1080p)", "url": "url2"},
            {"quality": "mp4 (720p)", "url": "url3"},
        ]
        
        sorted_links = self.downloader._sort_links_by_quality(links, "highest")
        self.assertEqual(sorted_links[0]["quality"], "mp4 (1080p)")
        
        sorted_links = self.downloader._sort_links_by_quality(links, "lowest")
        self.assertEqual(sorted_links[0]["quality"], "mp4 (360p)")

if __name__ == '__main__':
    unittest.main()