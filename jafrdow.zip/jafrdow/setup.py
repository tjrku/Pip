from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# قراءة المتطلبات من requirements.txt
def read_requirements():
    with open('requirements.txt', 'r', encoding='utf-8') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

def get_version():
    with open(os.path.join("jafrdow", "__init__.py"), "r", encoding="utf-8") as f:
        for line in f:
            if line.startswith("__version__"):
                return line.split("=")[1].strip().strip('"').strip("'")
    return "2.0.0"

setup(
    name="jafrdow",
    version=get_version(),
    author="Jafr",
    author_email="@up61",
    description="مكتبة Python لتنزيل مقاطع الفيديو من وسائل التواصل الاجتماعي",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/your-username/jafrdow",
    packages=find_packages(include=['jafrdow', 'jafrdow.*']),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.7",
    install_requires=read_requirements(),  # ⬅️ استخدام الدالة لقراءة المتطلبات
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov",
            "black",
            "flake8",
        ],
        "test": [
            "pytest>=6.0",
            "pytest-cov",
        ],
    },
    entry_points={
        "console_scripts": [
            "jafrdow=jafrdow.cli:main",
        ],
    },
    keywords=[
        "download", 
        "video", 
        "social media", 
        "youtube", 
        "tiktok", 
        "instagram",
        "twitter",
        "facebook",
        "arabic"
    ],
    project_urls={
        "Bug Reports": "https://github.com/your-username/jafrdow/issues",
        "Source": "https://github.com/your-username/jafrdow",
    },
)